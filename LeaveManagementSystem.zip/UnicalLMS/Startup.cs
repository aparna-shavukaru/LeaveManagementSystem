﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(UnicalLMS.Startup))]
namespace UnicalLMS
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
