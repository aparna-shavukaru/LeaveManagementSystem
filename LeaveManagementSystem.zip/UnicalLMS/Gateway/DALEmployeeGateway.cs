﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using UnicalLMS.Models;

namespace UnicalLMS.Gateway
{
    public class DALEmployeeGateway
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["LeaveManagenent"].ConnectionString;
        static readonly string conString = WebConfigurationManager.ConnectionStrings["LeaveManagenent"].ConnectionString;
        public List<Models.AppliedLeaveDetail> RMList(int EmployeeID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,EmployeeName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where  EmployeeID=" + EmployeeID, con); //RoleID=2 and
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<AppliedLeaveDetail> employeeList = new List<AppliedLeaveDetail>();
            while (dr.Read())
            {
                AppliedLeaveDetail emplotee = new AppliedLeaveDetail();
                emplotee.ReportingManagerID = (int)dr["EmployeeID"];
                // emplotee.ReportingManagerName = dr["FirstName"].ToString() + "" + dr["LastName"].ToString();
                employeeList.Add(emplotee);
            }
            con.Close();
            return employeeList.ToList();
        }

        public static int UpdateEmployeeDetails123(EmployeeDetail employee)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand(@"Update [dbo].[EmployeeDetails] set EmployeeCode = '" + employee.EmployeeCode + "' , FirstName = ' "+ employee.FirstName + "', LastName = '" + employee.LastName + "', Gender = '" + employee.Gender + "', GenderID = '" + employee.GenderID + "', DOB = '" + employee.DOB + "', EmailID = '" + employee.EmailID + "' , RoleID = ' "+ employee.RoleID + "', Address = '" + employee.Address + "', ReportingManager = '" + employee.ReportingManager + "', ReportingManagerID = '" + employee.ReportingManagerID + "',+  EmployeeName = '" + employee.EmployeeName + "', State = '" + employee.State + "', City = '" + employee.City + "', State = '" + employee.State + "', Address = '" + employee.Address + "'where EmployeeID= ' " + employee.EmployeeID + "' ", con);
            con.Open();
            int number = com.ExecuteNonQuery();
            con.Close();
            if (number > 0)
            {
                return number;
            }
            return number;
        }
        public string UpdateEmployeeDetails(EmployeeDetail employee)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"Update [dbo].[EmployeeDetails] set EmployeeCode = '" + employee.EmployeeCode + "' , FirstName = ' " + employee.FirstName + "', LastName = '" + employee.LastName + "', Gender = '" + employee.Gender + "', GenderID = '" + employee.GenderID + "', DOB = '" + employee.DOB + "', EmailID = '" + employee.EmailID + "' , RoleID = ' " + employee.RoleID + "', Address = '" + employee.Address + "', ReportingManager = '" + employee.ReportingManager + "', ReportingManagerID = '" + employee.ReportingManagerID + "',+  EmployeeName = '" + employee.EmployeeName + "', State = '" + employee.State + "', City = '" + employee.City + "', State = '" + employee.State + "', Address = '" + employee.Address + "'where EmployeeID= ' " + employee.EmployeeID + "' ", con);
            con.Open();
            int number = com.ExecuteNonQuery();
            con.Close();
            if (number > 0)
            {
                return "Employee details updated successfully!";
            }
            return "Employee Save Failed, Please Try Again!!!";
        }

        public bool IsEmailExist(string email)
        {
           bool isExists = false;
           // SqlConnection con = new SqlConnection(connectionString);
           // SqlConnection Connection = new SqlConnection(connectionString);
           //// string Query = "SELECT Username FROM EmployeeDetails WHERE Username=" + EmployeeID, con);
           //// SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,EmployeeName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where  EmployeeID=" + EmployeeID, con); //RoleID=2 and
           // SqlCommand Command = new   SqlCommand(@"SELECT Username FROM [UNI_LeaveManagementSystem].[dbo].[EmployeeDetails] WHERE IsActive=1 and Username='" + email+ "'", con); //RoleID=2 and

           // //Command.Parameters.Clear();
           // //Command.Parameters.Add("@Email", SqlDbType.VarChar).Value = email;
           // Connection.Open();
           // SqlDataReader dr = Command.ExecuteReader();
           // if (dr.Read())
           // {
           //     EmployeeDetail emplotee = new EmployeeDetail();
           //     if(dr["ReportingManagerID"].ToString()=="")
           //         isExists = false;
           //     else
           //     isExists = true;
           // }
           // Connection.Close();
           // dr.Close();
           // return isExists;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"SELECT Username FROM [UNI_LeaveManagementSystem].[dbo].[EmployeeDetails] WHERE IsActive=1 and Username='" + email + "'", con); //RoleID=2 and
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            EmployeeDetail employeeList = new EmployeeDetail();
             
            if (dr.HasRows)
            {
                    isExists = true;
                // emplotee.ReportingManagerName = dr["FirstName"].ToString() + "" + dr["LastName"].ToString();
            }
            else isExists = false;
            con.Close();
            return isExists;
        }

        public bool IsEmpIDExists(string empID)
        {
            bool isExists = false;
           
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"SELECT EmployeeCode FROM  EmployeeDetails WHERE IsActive=1 and EmployeeCode ='" + empID + "'", con); //RoleID=2 and
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            EmployeeDetail employeeList = new EmployeeDetail();

            if (dr.HasRows)
            {
                isExists = true;
                // emplotee.ReportingManagerName = dr["FirstName"].ToString() + "" + dr["LastName"].ToString();
            }
            else isExists = false;
            con.Close();
            return isExists;
        }

        
        public List<Models.EmployeeDetail> MangersListData(int EmployeeID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            //SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,(isnull(FirstName,'')+' '+ isnull(LastName,'')) as Name,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where  EmployeeID=" + EmployeeID, con); //RoleID=2 and
            //SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,EmployeeName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where RoleID=2 and 1 = CASE WHEN ISNULL('" + EmployeeID+ "',0)=0 THEN 1 WHEN  EmployeeID = '" + EmployeeID + "' THEN 1 ELSE 0 END", con); //RoleID=2 and
            SqlCommand com = new SqlCommand();
            if (EmployeeID == 0)
                com = new SqlCommand(@"SELECT EmployeeID as ReportingManagerID,EmployeeName as ReportingManager  FROM EmployeeDetails where RoleID=2  ", con); //RoleID=2 and
            else com = new SqlCommand(@"select distinct ReportingManagerID, ReportingManager from EmployeeDetails where ReportingManagerID = (select ReportingManagerID from EmployeeDetails where EmployeeID =" + EmployeeID + ")", con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<EmployeeDetail> employeeList = new List<EmployeeDetail>();
            while (dr.Read())
            {
                EmployeeDetail emplotee = new EmployeeDetail();
                emplotee.ReportingManagerID = (int)dr["ReportingManagerID"];
                emplotee.ReportingManager = dr["ReportingManager"].ToString();
                employeeList.Add(emplotee);
            }
            con.Close();
            return employeeList.ToList();
        }
        public List<EmployeeDetail> EmployeeList(int employeeId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"SELECT * FROM  EmployeeDetails where  EmployeeID=" + employeeId, con); //RoleID=2 and
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<EmployeeDetail> employeeList = new List<EmployeeDetail>();
            while (dr.Read())
            {
                EmployeeDetail emplotee = new EmployeeDetail();
                emplotee.EmployeeID = (int)dr["EmployeeID"];
                emplotee.EmployeeName = dr["EmployeeName"].ToString();
                emplotee.EmailID = dr["EmailID"].ToString(); 
                employeeList.Add(emplotee);
            }
            con.Close();
            return employeeList.ToList();
        }

        public List<Models.EmployeeDetail> MangersList(int EmployeeID)
        {
            SqlConnection con = new SqlConnection(connectionString);
            //SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,(isnull(FirstName,'')+' '+ isnull(LastName,'')) as Name,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where  EmployeeID=" + EmployeeID, con); //RoleID=2 and
            //SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,EmployeeName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails where RoleID=2 and 1 = CASE WHEN ISNULL('" + EmployeeID+ "',0)=0 THEN 1 WHEN  EmployeeID = '" + EmployeeID + "' THEN 1 ELSE 0 END", con); //RoleID=2 and
            SqlCommand com = new SqlCommand();
            if (EmployeeID == 0)
                com = new SqlCommand(@"SELECT distinct EmployeeID as ReportingManagerID,EmployeeName as ReportingManager  FROM EmployeeDetails where RoleID=2 and IsActive=1", con); //RoleID=2 and
            else com = new SqlCommand(@"select distinct ReportingManagerID, ReportingManager from EmployeeDetails where ReportingManagerID = (select ReportingManagerID from EmployeeDetails where EmployeeID =" + EmployeeID + ")  and IsActive=1", con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<EmployeeDetail> employeeList = new List<EmployeeDetail>();
            while (dr.Read())
            {
                EmployeeDetail emplotee = new EmployeeDetail();
                emplotee.ReportingManagerID = (int)dr["ReportingManagerID"];
                emplotee.ReportingManager = dr["ReportingManager"].ToString();
                //emplotee.EmailID = dr["EmailID"].ToString();
                employeeList.Add(emplotee);
            }
            con.Close();
            return employeeList.ToList();
        }

        internal static string UpdateEmployeeInfo(ref EmployeeDetail employee)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand(@"Update[dbo].[EmployeeDetails] set EmployeeCode = '" + employee.EmployeeCode + "', FirstName = '" + employee.FirstName + "', LastName = '" + employee.LastName + "', Gender = '" + employee.Gender + "', GenderID = '" + employee.GenderID + "', DOB = '" + employee.DOB + "', EmailID = '" + employee.EmailID + "', RoleID = '" + employee.RoleID + "', Address = '" + employee.Address + "', ReportingManager = '" + employee.ReportingManager + "', ReportingManagerID = '" + employee.ReportingManagerID + "', EmployeeName = '" + employee.EmployeeName + "', State = '" + employee.State + "', City = '" + employee.City + "'  where EmployeeID =' " + employee.EmployeeID + "' ", con);
            //Update [dbo].[EmployeeDetails] set EmployeeCode = '" + employee.EmployeeCode + "' , FirstName = ' " + employee.FirstName + "', LastName = '" + employee.LastName + "', Gender = '" + employee.Gender + "', GenderID = '" + employee.GenderID + "', DOB = '" + employee.DOB + "', EmailID = '" + employee.EmailID + "' , RoleID = ' " + employee.RoleID + "', Address = '" + employee.Address + "', ReportingManager = '" + employee.ReportingManager + "', ReportingManagerID = '" + employee.ReportingManagerID + "',+  EmployeeName = '" + employee.EmployeeName + "', State = '" + employee.State + "', City = '" + employee.City + "', State = '" + employee.State + "', Address = '" + employee.Address + "'where EmployeeID= ' " + employee.EmployeeID + "' ", con);

            con.Open();
            int number = com.ExecuteNonQuery();
            con.Close();
            if (number > 0)
            {
                return "Employee details updated successfully!";
            }
            return "Employee Save Failed, Please Try Again!!!";
        }

        public List<EmployeeDetail> AllEmployeeEmailList(string employeeName)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand com = new SqlCommand(@"SELECT EmployeeID,EmployeeCode,FirstName ,LastName,EmployeeName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID FROM  EmployeeDetails Where (isnull(FirstName,'')+' '+ isnull(LastName,'')) ='" + employeeName + "' ", con);
            con.Open();
            SqlDataReader dr = com.ExecuteReader();
            List<EmployeeDetail> EmployeeNames = new List<EmployeeDetail>();
            while (dr.Read())
            {
                EmployeeDetail employee = new EmployeeDetail();
                employee.EmployeeID = (int)dr["EmployeeID"];
                employee.FirstName = dr["EmployeeName"].ToString();
                employee.EmailID = dr["EmailID"].ToString();
                EmployeeNames.Add(employee);
            }
            con.Close();
            return EmployeeNames.ToList();
        }

        internal static string UpdateLeaveInfo1(ref AppliedLeaveDetail appliedLeaveDetail)
        {
            SqlConnection con = new SqlConnection(conString);
            SqlCommand com = new SqlCommand(@"Update AppliedLeaveDetails set LeaveStatusID = '" + appliedLeaveDetail.LeaveStatusID + "', ApprovedStartDate = '" + appliedLeaveDetail.ApprovedStartDate + "', ApprovedEndDate = '" + appliedLeaveDetail.ApprovedEndDate + "', ApprovedNoofDays = '" + appliedLeaveDetail.ApprovedNoofDays + "', ApprovedReason = '" + appliedLeaveDetail.ApprovedReason + "' where LeaveID  =' " + appliedLeaveDetail.LeaveID + "' ", con);
            //Update [dbo].[EmployeeDetails] set EmployeeCode = '" + employee.EmployeeCode + "' , FirstName = ' " + employee.FirstName + "', LastName = '" + employee.LastName + "', Gender = '" + employee.Gender + "', GenderID = '" + employee.GenderID + "', DOB = '" + employee.DOB + "', EmailID = '" + employee.EmailID + "' , RoleID = ' " + employee.RoleID + "', Address = '" + employee.Address + "', ReportingManager = '" + employee.ReportingManager + "', ReportingManagerID = '" + employee.ReportingManagerID + "',+  EmployeeName = '" + employee.EmployeeName + "', State = '" + employee.State + "', City = '" + employee.City + "', State = '" + employee.State + "', Address = '" + employee.Address + "'where EmployeeID= ' " + employee.EmployeeID + "' ", con);

            con.Open();
            int number = com.ExecuteNonQuery();
            con.Close();
            if (number > 0)
            {
                return "Employee details updated successfully!";
            }
            return "Employee Save Failed, Please Try Again!!!";
        }
        public static string UpdateLeaveInfo(ref AppliedLeaveDetail appliedLeaveDetail)
        {
            int result = 0;string res = "";
            try
            {
                SqlConnection Connection = new SqlConnection(conString);
                Connection.Open();
                try
                {
                    SqlCommand Command = new SqlCommand("Pr_InsertUpdateLeaveDetails", Connection);
                    Command.CommandType = System.Data.CommandType.StoredProcedure;
                    Command.Parameters.Add(new SqlParameter("@LeaveStatusID", appliedLeaveDetail.LeaveStatusID));
                    Command.Parameters.Add(new SqlParameter("@ApprovedStartDate", appliedLeaveDetail.ApprovedStartDate));
                    Command.Parameters.Add(new SqlParameter("@ApprovedEndDate", appliedLeaveDetail.ApprovedEndDate));
                    Command.Parameters.Add(new SqlParameter("@ApprovedNoofDays", appliedLeaveDetail.ApprovedNoofDays));
                    Command.Parameters.Add(new SqlParameter("@ApprovedReason", appliedLeaveDetail.ApprovedReason));
                    Command.Parameters.Add(new SqlParameter("@LeaveID", appliedLeaveDetail.LeaveID));
                    Command.Parameters.Add(new SqlParameter("@EmployeeID", appliedLeaveDetail.EmployeeID));
                    SqlDataReader rdr = Command.ExecuteReader();
                    while (rdr.Read())
                    {
                        result = (rdr.GetInt32(0));

                    }
                    rdr.Close();

                }
                catch (Exception e)
                {


                }
                finally
                {
                    Connection.Close();
                }



            }
            catch (Exception ex)
            {
            }
            return res;

        }
        public static int UpdateEmployeeDetails1(ref UnicalLMS.Models.EmployeeDetail objEmp)
        {
            int result = 0;
            try
            {
                SqlConnection Connection = new SqlConnection(conString);
                Connection.Open();
                try
                {
                    SqlCommand Command = new SqlCommand("Pr_InsertEmployeeDetails", Connection);
                    Command.CommandType = System.Data.CommandType.StoredProcedure;
                    Command.Parameters.Add(new SqlParameter("@EmployeeCode", objEmp.EmployeeCode));
                    Command.Parameters.Add(new SqlParameter("@FirstName", objEmp.FirstName));
                    Command.Parameters.Add(new SqlParameter("@LastName", objEmp.LastName));
                    Command.Parameters.Add(new SqlParameter("@Gender", objEmp.Gender));
                    Command.Parameters.Add(new SqlParameter("@GenderID", objEmp.GenderID));
                    Command.Parameters.Add(new SqlParameter("@Address", objEmp.Address));
                    Command.Parameters.Add(new SqlParameter("@City", objEmp.City));
                   // Command.Parameters.Add(new SqlParameter("@DOB", objEmp.DOB));
                    Command.Parameters.Add(new SqlParameter("@EmailID", objEmp.EmailID));
                    Command.Parameters.Add(new SqlParameter("@IsActive", objEmp.IsActive));
                    Command.Parameters.Add(new SqlParameter("@ReportingManager", objEmp.ReportingManager));
                    Command.Parameters.Add(new SqlParameter("@ReportingManagerID", objEmp.ReportingManagerID));
                    Command.Parameters.Add(new SqlParameter("@RoleID", objEmp.RoleID));
                    Command.Parameters.Add(new SqlParameter("@State", objEmp.State));
                    Command.Parameters.Add(new SqlParameter("@Username", objEmp.Username));
                    Command.Parameters.Add(new SqlParameter("@Password", objEmp.Password));
                    Command.Parameters.Add(new SqlParameter("@EmployeeID", objEmp.EmployeeID));
                    SqlDataReader rdr = Command.ExecuteReader();
                    while (rdr.Read())
                    {
                        result = (rdr.GetInt32(0));

                    }
                    rdr.Close();

                }
                catch (Exception e)
                {
                    

                }
                finally
                {
                    Connection.Close();
                }



            }
            catch (Exception ex)
            {
            }
            return result;

        }

    }
}