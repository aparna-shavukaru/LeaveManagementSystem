﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnicalLMS.BusinessLayer;
using UnicalLMS.Models;

namespace UnicalLMS.Controllers
{
    public class EmployeeDetailsController : Controller
    {
        private UNI_LeaveManagementSystemEntities db = new UNI_LeaveManagementSystemEntities();
        BusinessLayer.BLEmployee eManager = new BLEmployee();
        // GET: EmployeeDetails
        public ActionResult EmployeeList1()
        {
            var employeeDetails = db.EmployeeDetails.Include(e => e.Gender_Lkp).Include(e => e.Role_Lkp).Where(m => m.IsActive == true).OrderByDescending(e => e.EmployeeID);
            // employeeDetails = employeeDetails.ToList();
            return View(employeeDetails.ToList());
        }
        public ActionResult EmployeeList(string searchBy, string search)
        {
            if (searchBy == "Gender")
            {
                return View(db.EmployeeDetails.Where(x => x.Gender == search || search == null).ToList());
            }
            else if (searchBy == "Name")
            {
                return View(db.EmployeeDetails.Where(x => x.EmployeeName.Contains(search) || search == null).ToList());
            }
            else
            {
                return View(db.EmployeeDetails.Include(e => e.Gender_Lkp).Include(e => e.Role_Lkp).Where(m => m.IsActive == true).OrderByDescending(e => e.EmployeeID).ToList());
            }
        }
        // GET: EmployeeDetails
        public ActionResult ManageEmployee()
        {
            var employeeDetails = db.EmployeeDetails.Include(e => e.Gender_Lkp).Include(e => e.Role_Lkp).Where(m => m.IsActive == true).OrderByDescending(e => e.EmployeeID);
            // employeeDetails = employeeDetails.ToList();
            return View(employeeDetails.ToList());
        }
        // GET: EmployeeDetails/Details/5
        public ActionResult ViewEmployee(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = db.EmployeeDetails.Find(id);
            if (employeeDetail == null)
            {
                return HttpNotFound();
            }
            return View(employeeDetail);
        }

        // GET: EmployeeDetails/Create
        public ActionResult AddEmployee()
        {
            try
            {
                Session["RMID"] = 0; Session["PLVal"] = "0";
                Session["RMName"] = ""; 
                 UnicalLMS.Models.EmployeeDetail emp = new EmployeeDetail();
                List<SelectListItem> ManagerList1 = new List<SelectListItem>();
                IEnumerable<SelectListItem> ManagerList = new List<SelectListItem>();
                //model.DistributorList = distList;
                //EmployeeDetail.RMLists = ManagerList1;
                //ManagerList1 = eManager.MangersListData(0);
                //foreach (RMLists in ManagerList1)
                //{
                //    distList.Add(new SelectListItem { Text = d.ReportingManager, Value = d.ReportingManagerID.ToString() });
                //} 
                //emp.RMList = ViewBag.RMList;
                emp.IsActive = true;
                ViewBag.RMList = eManager.MangersList(0);
                ViewBag.GenderID = new SelectList(db.Gender_Lkp, "GenderID", "Gender");
                ViewBag.RoleID = new SelectList(db.Role_Lkp, "RoleID", "RoleName");
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View();
        }

        // POST: EmployeeDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddEmployee([Bind(Include = "EmployeeID,EmployeeCode,FirstName,LastName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID,InsertedBy,InsertedDate,ModifiedBy,ModifiedDate,EmployeeName,Username,Password")] EmployeeDetail employeeDetail)
        {
            try
            {
                employeeDetail.EmployeeID = 0;
                employeeDetail.IsActive = true;
                try { 
                if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                    employeeDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
                if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                    employeeDetail.ReportingManager = Session["RMName"].ToString();
                }
                catch (DbEntityValidationException ex)
                {
                    foreach (var errors in ex.EntityValidationErrors)
                    {
                        foreach (var validationError in errors.ValidationErrors)
                        {
                            // get the error message 
                            string errorMessage = validationError.ErrorMessage;
                        }
                    }
                }
                if (employeeDetail.ReportingManagerID == 0)
                {
                    Session["RMID"] = "0"; Session["PLVal"] = "1";
                    ViewBag.RMList = eManager.MangersList(0);
                    ViewBag.GenderID = new SelectList(db.Gender_Lkp, "GenderID", "Gender", employeeDetail.GenderID);
                    ViewBag.RoleID = new SelectList(db.Role_Lkp, "RoleID", "RoleName", employeeDetail.RoleID);
                    return View(employeeDetail);
                }
                if (ModelState.IsValid)
                {                   
                    employeeDetail.EmployeeName = employeeDetail.FirstName.Trim() + ' ' + employeeDetail.LastName.Trim();
                    if (employeeDetail.GenderID == 1) employeeDetail.Gender = "Male";
                    else if (employeeDetail.GenderID == 2) employeeDetail.Gender = "Female";
                    //employeeDetail.ConfirmPassword = employeeDetail.Password;
                employeeDetail.IsActive = true;
                db.EmployeeDetails.Add(employeeDetail);
                db.SaveChanges();
                return RedirectToAction("EmployeeList");
            }
            ViewBag.RMList = eManager.MangersList(0);
            ViewBag.GenderID = new SelectList(db.Gender_Lkp, "GenderID", "Gender", employeeDetail.GenderID);
            ViewBag.RoleID = new SelectList(db.Role_Lkp, "RoleID", "RoleName", employeeDetail.RoleID);
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(employeeDetail);
        }

        // GET: EmployeeDetails/Edit/5
        public ActionResult EditEmployee(int? id)
        {
            if (id == null)
            {
                //return RedirectToAction("Contact", "Home");
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = db.EmployeeDetails.Find(id);
            try
            {
                if (employeeDetail == null)
                {
                    return HttpNotFound();
                }
                //if (Convert.ToInt32(Session["RoleID"].ToString()) == 1)//if (id == Convert.ToInt32(Session["EmployeeID"].ToString()))
                //{
                    //Session["RMID"] = null; Session["RMName"] = null;
                    Session["RMID"] = employeeDetail.ReportingManagerID;
                    Session["RMName"] = employeeDetail.ReportingManager;
                    ViewBag.RMList = eManager.MangersList(employeeDetail.EmployeeID);                   
                    Session["EmployeeUsername"] = employeeDetail.Username;
                    Session["EmployeePassword"] = employeeDetail.Password;
                    //employeeDetail.RMList = ViewBag.RMList;
                    //ViewBag.RMList = new SelectList(employeeDetail.RMList,
                    //    "ReportingManagerID",
                    //    "ReportingManager" ,employeeDetail.ReportingManagerID);
                //}
                    ViewBag.RMLists = eManager.MangersList(0);
                    ViewBag.RMList = new SelectList(ViewBag.RMLists, "ReportingManagerID", "ReportingManager", employeeDetail.ReportingManagerID);
                    employeeDetail.IsActive = true;
                    
                    ViewBag.GenderID = new SelectList(db.Gender_Lkp, "GenderID", "Gender", employeeDetail.GenderID);
                    ViewBag.RoleID = new SelectList(db.Role_Lkp, "RoleID", "RoleName", employeeDetail.RoleID);
                
                //else return RedirectToAction("NotAuthorized", "Home");// return not authorized to edit empl details;
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(employeeDetail);
            }

        // POST: EmployeeDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditEmployee([Bind(Include = "EmployeeID,EmployeeCode,FirstName,LastName,MI,GenderID,Gender,DOB,DepartmentID,EmailID,RoleID,Address,City,State,ReportingManager,ReportingManagerID,InsertedBy,InsertedDate,ModifiedBy,ModifiedDate,EmployeeName,Username,Password")] EmployeeDetail employeeDetail)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                EmployeeDetail employeeDetails = db.EmployeeDetails.Find(employeeDetail.EmployeeID);
                if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                        employeeDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
                    if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                        employeeDetail.ReportingManager = Session["RMName"].ToString();
                    employeeDetail.IsActive = true;
                    if (employeeDetail.GenderID == 1) employeeDetail.Gender = "Male";
                    else if (employeeDetail.GenderID == 2) employeeDetail.Gender = "Female";
                    employeeDetail.EmployeeName = employeeDetail.FirstName.Trim() + ' ' + employeeDetail.LastName.Trim();
                    employeeDetail.Username = employeeDetails.Username.ToString();
                    employeeDetail.Password = employeeDetails.Password.ToString();
                //employeeDetail.ConfirmPassword = employeeDetail.Password;
                
               string  result = UnicalLMS.Gateway.DALEmployeeGateway.UpdateEmployeeInfo(ref employeeDetail);
                //res = BLEmployee.UpdateEmployeeDetails(ref employeeDetail);
                //db.Entry(employeeDetail).State = EntityState.Modified;
                //db.SaveChanges();
                    return RedirectToAction("EmployeeList");
                //}
                ViewBag.RMList = eManager.MangersList(employeeDetail.EmployeeID);
                ViewBag.GenderID = new SelectList(db.Gender_Lkp, "GenderID", "Gender", employeeDetail.GenderID);
                ViewBag.RoleID = new SelectList(db.Role_Lkp, "RoleID", "RoleName", employeeDetail.RoleID);
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(employeeDetail);
        }

        // GET: EmployeeDetails/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = db.EmployeeDetails.Find(id);
            if (employeeDetail == null)
            {
                  return HttpNotFound();
            }
            //if (Convert.ToInt32(Session["EmployeeID"].ToString()) == 1) { 
            //    if (id == Convert.ToInt32(Session["EmployeeID"].ToString()))
            //    {
            //        return View(employeeDetail);
            //    }
            //}
            return View(employeeDetail); //else return RedirectToAction("NotAuthorized", "Home");// return not authorized to edit empl details;
        }

        // POST: EmployeeDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmployeeDetail employeeDetail = db.EmployeeDetails.Find(id);
            employeeDetail.IsActive = false;
            db.Entry(employeeDetail).State = EntityState.Modified;
            //db.EmployeeDetails.Remove(employeeDetail);
            db.SaveChanges();
            return RedirectToAction("EmployeeList");
        }
        public JsonResult GetEmployeeName(int ReportingManagerID)
        {
            Session["RMID"] = ReportingManagerID;
            var employeeName = eManager.EmployeeList(ReportingManagerID);
            return Json(employeeName.ToList(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetEmployeeEmail(int ReportingManagerID)
        {
            EmployeeDetail empModel = new EmployeeDetail();
            Session["RMID"] = ReportingManagerID; 
            var employeeName = eManager.EmployeeList(ReportingManagerID);
            ////
            List<EmployeeDetail> list2 = employeeName;
            foreach (EmployeeDetail obj in list2)
            {
                empModel.ReportingManager = obj.EmployeeName;
                Session["RMName"] = obj.EmployeeName;
                //objmed.VisitDate = obj.Visitname + "";
                //objmed.VisitID = obj.VisitID + "";
                //objmed.MemberID = obj.MemberID;
                //objmed.MemberMedicationID = obj.MemberMedicationID;

                //objmed.GroupID = obj.GroupID + "";


                //objmed.MedicineName += obj.MedicationName + ",";
                //if (obj.SignedDate.Year != 1900) objmed.MedicineStartDate = obj.SignedDate.ToString("dd/MM/yyyy");
                //if (obj.CompletedDate.Year != 1900) objmed.MedicineEndDate = obj.CompletedDate.ToString("dd/MM/yyyy");

            }
            ////
            //Session["RMName"] = employeeName.FirstOrDefault().ReportingManager.ToString();
            return Json(employeeName.ToList(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult IsEmailExists(string email)
        {
            bool isCodeExists = eManager.IsEmailExists(email);

            if (isCodeExists)
                return Json(true, JsonRequestBehavior.AllowGet);
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult IsEmpCodeExists(string empID)
        {
            bool isCodeExists = eManager.IsEmpIDExists(empID);
            if (isCodeExists)
                return Json(true, JsonRequestBehavior.AllowGet);
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        

        //public JsonResult GetEmployeeName11(int ReportingManagerID)
        //{
        //    Session["RMID"] = ReportingManagerID;
        //    var employeeName = eManager.EmployeeList(ReportingManagerID);
        //    //return View("AddEmployee");//
        //    Json(employeeName.ToList(), JsonRequestBehavior.AllowGet);
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
