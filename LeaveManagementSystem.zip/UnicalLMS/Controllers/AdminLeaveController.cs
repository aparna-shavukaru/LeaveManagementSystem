﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnicalLMS.Models;
using UnicalLMS.BusinessLayer;

namespace UnicalLMS.Controllers
{
    public class AdminLeaveController : Controller
    {
        private UNI_LeaveManagementSystemEntities db = new UNI_LeaveManagementSystemEntities();
        BusinessLayer.BLEmployee eManager = new BLEmployee();
        // GET: AdminLeave
        public ActionResult AdminAllLeaveDetails()
        {
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1)
                                                            .Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp)
                                                            .Include(a => a.LeaveType_Lkp)
                                                            .OrderByDescending(m => m.LeaveID);  
            return View(appliedLeaveDetails.ToList());
        }
        // GET: AdminLeave - Approved leave details
        public ActionResult AdminApprovedLeaveDetails()
        {
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail)
                                                            .Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2)
                                                            .Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);

            //appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 1).OrderByDescending(m => m.LeaveID);
            //on 22/06/2020 LeaveStatusID=1 is for Aprroved by RM and Waiting for Admin Approval ; LeaveStatusID=4 Approved by Admin - The final Approval
            appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 4).OrderByDescending(m => m.LeaveID);
            return View(appliedLeaveDetails.ToList());
        }

        // GET: AdminLeave - NOt Approved(Rejected) leave details
        public ActionResult AdminNotApprovedLeaveDetails()
        {
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2)
                                                                                           .Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 2).OrderByDescending(m => m.LeaveID);
            return View(appliedLeaveDetails.ToList());
        }
        // GET: AdminLeave - - Pending(Waiting for approval) leave details
        public ActionResult AdminPendingLeaveDetails()
        {
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 1).OrderByDescending(m => m.LeaveID); // on 22/06/2020
            return View(appliedLeaveDetails.ToList());
        }

        // GET: AdminLeave/Details/5
        public ActionResult AdminViewLeaveDetails(int? LeaveID)
        {
            if (LeaveID == null)
            {
               return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(LeaveID);
            if (appliedLeaveDetail == null)
            {
                return HttpNotFound();
            }
            return View(appliedLeaveDetail);
        }

        // GET: AdminLeave/Create
        public ActionResult AdminApplyLeave()
        {
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            ViewBag.ReportingManagerID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus");
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType");
            return View();
        }

        // POST: AdminLeave/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminApplyLeave([Bind(Include = "LeaveID,EmployeeID,LeaveTypeID,StartDate,EndDate,NoofLeaveTaken,ReportingManagerID,ReportingManagerMailID,ModuleLeadMailID,ReasonforLeave,LeaveStatusID,EmergencyContact,InsertedDate,InsertedBy,ModifiedDate,ModifiedBy,ApprovedStartDate,ApprovedEndDate,ApprovedNoofDays,ApprovedBy,ApprovedReason,ApprovedDate,EmployeeName,ReportingManager")] AppliedLeaveDetail appliedLeaveDetail)
        {
            if (ModelState.IsValid)
            {
                db.AppliedLeaveDetails.Add(appliedLeaveDetail);
                db.SaveChanges();
                return RedirectToAction("AdminAllLeaveDetails");
            }

            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
            ViewBag.ReportingManagerID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ReportingManagerID);
            ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.EmployeeID);
            ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            return View(appliedLeaveDetail);
        }

        // GET: AdminLeave/Edit/5
        public ActionResult AdminEditLeave(int? LeaveID)
        {
            if (LeaveID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(LeaveID);
            appliedLeaveDetail.EmployeeName = appliedLeaveDetail.EmployeeName;
            int EmployeeID = appliedLeaveDetail.EmployeeID;
            //int EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            //removed below condition, because every leave has to approve by Admin, on 22/06/2020
            //if (EmployeeID == appliedLeaveDetail.ReportingManagerID)
            //{
                if (appliedLeaveDetail == null)
                {
                    return HttpNotFound();
                }
            ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
                ViewBag.EmployeeID = EmployeeID;
                ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
                //
                ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                ViewBag.ReportingManagerID = appliedLeaveDetail.ReportingManagerID;
            /********** on 22/06/2020 Leave status as 'Admin Approval' should not be bind for roles Employee, Manager *************/
            int RoleID = Convert.ToInt32(Session["RoleID"].ToString());
            if (RoleID == 1)
            {
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID).Where(a => a.Value != "3");
            }
            else
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            
                return View(appliedLeaveDetail);
            //}
            //else 
            //    return RedirectToAction("NotAuthorized", "ManagerLeave"); //If login person is not authorized to edit the leave, we are redirecting to this page
        }

        // POST: AdminLeave/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminEditLeave([Bind(Include = "LeaveID,EmployeeID,LeaveTypeID,StartDate,EndDate,NoofLeaveTaken,ReportingManagerID,ReportingManagerMailID,ModuleLeadMailID,ReasonforLeave,LeaveStatusID,EmergencyContact,InsertedDate,InsertedBy,ModifiedDate,ModifiedBy,ApprovedStartDate,ApprovedEndDate,ApprovedNoofDays,ApprovedBy,ApprovedReason,ApprovedDate,EmployeeName,ReportingManager")] AppliedLeaveDetail appliedLeaveDetail)
        {
            #region newcode
            EmployeeDetail employeeDetail = new EmployeeDetail();
            employeeDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            ////////employeeDetail = db.EmployeeDetails.Find(employeeDetail.EmployeeID);
            ////////Session["RMID"] = employeeDetail.ReportingManagerID;
            ////////Session["RMName"] = employeeDetail.ReportingManager;
            /* on 22/06/2020
            if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                appliedLeaveDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
            if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                appliedLeaveDetail.ReportingManager = Session["RMName"].ToString();
                */
            AppliedLeaveDetail appliedLeaveDetails = db.AppliedLeaveDetails.Find(appliedLeaveDetail.LeaveID);
            appliedLeaveDetail.EmployeeID = appliedLeaveDetails.EmployeeID; //Convert.ToInt32(Session["EmployeeID"].ToString());
            appliedLeaveDetail.EmployeeName = appliedLeaveDetails.EmployeeName;
            appliedLeaveDetail.ReportingManagerID = appliedLeaveDetails.ReportingManagerID;// on 22/06/2020
            appliedLeaveDetail.ReportingManager = appliedLeaveDetails.ReportingManager;  // on 22/06/2020
            ////appliedLeaveDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            ////appliedLeaveDetail.EmployeeName = appliedLeaveDetail.EmployeeName;
            //appliedLeaveDetail.LeaveStatusID = 3;
            try
            {
                if (ModelState.IsValid)
                {
                    string result = UnicalLMS.Gateway.DALEmployeeGateway.UpdateLeaveInfo(ref appliedLeaveDetail);
                    //db.Entry(appliedLeaveDetail).State = EntityState.Modified;
                    //db.SaveChanges();
                    return RedirectToAction("AdminAllLeaveDetails");
                }
                ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                ViewBag.ReportingManagerID = appliedLeaveDetail.ReportingManagerID;
                ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.EmployeeID);
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
                ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            #endregion 
            #region oldcode
            //if (ModelState.IsValid)
            //{
            //    db.Entry(appliedLeaveDetail).State = EntityState.Modified;
            //    db.SaveChanges();
            //    return RedirectToAction("AdminAllLeaveDetails");
            //}
            //ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
            //ViewBag.ReportingManagerID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ReportingManagerID);
            //ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.EmployeeID);
            //ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
            //ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            #endregion
            return View(appliedLeaveDetail);
        }

        // GET: AdminLeave/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                 return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(id);
            if (appliedLeaveDetail == null)
            {
                 return HttpNotFound();
            }
            return View(appliedLeaveDetail);
        }

        // POST: AdminLeave/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(id);
            db.AppliedLeaveDetails.Remove(appliedLeaveDetail);
            db.SaveChanges();
            return RedirectToAction("AdminAllLeaveDetails");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
