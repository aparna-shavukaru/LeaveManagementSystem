﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UnicalLMS.Controllers
{
    public class LoginController : Controller
    {
        [AllowAnonymous]
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult FormSubmit()
        {
            //Validate Google recaptcha here
            var response = Request["g-recaptcha-response"];
            string secretKey = "6LfP47sUAAAAABgUetiETk_Iu28KZq3I6g36loOR";
            var client = new System.Net.WebClient();
            var result = client.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secretKey, response));
            var obj = JObject.Parse(result);
            var status = (bool)obj.SelectToken("success");
            ViewBag.Message = status ? "Google reCaptcha validation success" : "Google reCaptcha validation failed";

            //When you will post form for save data, you should check both the model validation and google recaptcha validation
            //EX.
            /* if (ModelState.IsValid && status)
            {

            }*/

            //Here I am returning to Index page for demo perpose, you can use your view here
            return View("Login");
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult login(Models.EmployeeDetail u)
        {
            try
            {
                //if (ModelState.IsValid)
                //{
                using (UnicalLMS.Models.UNI_LeaveManagementSystemEntities db = new Models.UNI_LeaveManagementSystemEntities())
                {
                    var v = db.EmployeeDetails.Where(a => a.Username.Equals(u.Username.ToLower().Trim()) && a.Password.Equals(u.Password.ToLower().Trim())).FirstOrDefault();
                    if (v != null && v.IsActive == true)
                    {
                        var EmpID = v.EmployeeID.ToString();//db.UserDetails.Where( m => m.EmployeeID.Equals(m.EmployeeID)).FirstOrDefault();
                        Session["EmployeeID"] = EmpID.ToString();
                        Session["RoleID"] = v.RoleID.ToString();
                        Session["log"] = Session["Username"] = v.Username.ToString();
                        //return RedirectToAction("Dashboard");
                        if (Session["RoleID"].ToString() == "1")
                            return RedirectToAction("AdminAllLeaveDetails", "AdminLeave");
                        if (Session["RoleID"].ToString() == "2")
                            return RedirectToAction("ManagerLeaveDetailsList", "ManagerLeave");
                        if (Session["RoleID"].ToString() == "3")
                            return RedirectToAction("EmpLeaveHistory", "EmployeLeave");
                    }
                    else
                    {
                        ViewBag.Message = "Invalid Credentials";
                        //ModelState.AddModelError(string.Empty, "Invalid Credentials");
                        return View();
                    }
                }
                return View();// return RedirectToAction("About", "Home");
                //}
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }

            return View(u);
        }

    }
}