﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using UnicalLMS.BusinessLayer;
using UnicalLMS.Models;

namespace UnicalLMS.Controllers
{
    public class ManagerLeaveController : Controller
    {
        private UNI_LeaveManagementSystemEntities db = new UNI_LeaveManagementSystemEntities();
        BusinessLayer.BLEmployee eManager = new BLEmployee();
        // GET: ManagerLeave
        // THis method shows all employees applied leaves information list
        public ActionResult ManagerLeaveDetailsList()
        {
            int EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(m => m.ReportingManagerID == EmployeeID).OrderByDescending(m => m.LeaveID);
         
            return View(appliedLeaveDetails.ToList());
        }
        // GET: ManagerApprovedLeaveList - Approved leave details
        public ActionResult ManagerApprovedLeaveList()
        {
            int EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 4).OrderByDescending(m => m.LeaveID);//on 22/06/2020
            return View(appliedLeaveDetails.ToList());
        }

        // GET: ManagerNotApprovedLeaveList - NOt Approved(Rejected) leave details
        public ActionResult ManagerNotApprovedLeaveList()
        {
            int EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(m => m.ReportingManagerID == EmployeeID).OrderByDescending(m => m.LeaveID);
            appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 2);
            return View(appliedLeaveDetails.
                ToList());
        }
        // GET: ManagerPendingLeaveList - - Pending(Waiting for approval) leave details
        public ActionResult ManagerPendingLeaveList()
        {
            int EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            var appliedLeaveDetails = db.AppliedLeaveDetails.Include(a => a.EmployeeDetail).Include(a => a.EmployeeDetail1).Include(a => a.EmployeeDetail2).Include(a => a.LeaveStatus_Lkp).Include(a => a.LeaveType_Lkp);
            appliedLeaveDetails = appliedLeaveDetails.Where(m => m.ReportingManagerID == EmployeeID).OrderByDescending(m => m.LeaveID);
            //appliedLeaveDetails = appliedLeaveDetails.Where(a => a.LeaveStatusID == 3);
            appliedLeaveDetails = appliedLeaveDetails.Where(a => (a.LeaveStatusID == 3)) ; //on 22/06/2020
            return View(appliedLeaveDetails.ToList());
        }


        // GET: ManagerLeave/Details/5
        public ActionResult ManagerViewLeaveDetails(int? LeaveID)
        {
            if (LeaveID == null)
            {
                //return RedirectToAction("Contact", "Home");
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(LeaveID);
            try
            {
                if (appliedLeaveDetail == null)
                {
                    // return RedirectToAction("Contact", "Home");
                    return HttpNotFound();
                }
                if (appliedLeaveDetail.EmployeeID == Convert.ToInt32(Session["EmployeeID"].ToString()) || appliedLeaveDetail.ReportingManagerID == Convert.ToInt32(Session["EmployeeID"].ToString()))
                {
                    return View(appliedLeaveDetail);
               // return not authorized to edit empl details;
                }
                else return RedirectToAction("NotAuthorized");
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(appliedLeaveDetail);
        }
        public ActionResult NotAuthorized()
        {
            return View();
        }

        // GET: EmployeLeave/Create
        public ActionResult ManagerApplyforLeave()
        {
            EmployeeDetail empdetails = new EmployeeDetail();
            empdetails.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            EmployeeDetail employeeDetail = db.EmployeeDetails.Find(empdetails.EmployeeID);

            ViewBag.RMList = eManager.MangersList(empdetails.EmployeeID);
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            ViewBag.ReportingManagerID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", employeeDetail.EmployeeID);
            ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", employeeDetail.ReportingManagerID);
            ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus");
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType");
            return View();
        }

        // POST: EmployeLeave/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ManagerApplyforLeave([Bind(Include = "LeaveID,EmployeeID,LeaveTypeID,StartDate,EndDate,NoofLeaveTaken,ReportingManagerID,ReportingManagerMailID,ModuleLeadMailID,ReasonforLeave,LeaveStatusID,EmergencyContact,InsertedDate,InsertedBy,ModifiedDate,ModifiedBy,ApprovedStartDate,ApprovedEndDate,ApprovedNoofDays,ApprovedBy,ApprovedReason,ApprovedDate,EmployeeName,ReportingManager")] AppliedLeaveDetail appliedLeaveDetail)
        {
            appliedLeaveDetail.LeaveID = 0;
            EmployeeDetail employeeDetail = new EmployeeDetail();
            employeeDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            employeeDetail = db.EmployeeDetails.Find(employeeDetail.EmployeeID);
            Session["RMID"] = employeeDetail.ReportingManagerID;
            Session["RMName"] = employeeDetail.ReportingManager;
            if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                appliedLeaveDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
            if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                appliedLeaveDetail.ReportingManager = Session["RMName"].ToString();
            appliedLeaveDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            appliedLeaveDetail.LeaveStatusID = 3;
            if (ModelState.IsValid)
            {
                appliedLeaveDetail.EmployeeName = employeeDetail.EmployeeName;
                db.AppliedLeaveDetails.Add(appliedLeaveDetail);
                db.SaveChanges();
                return RedirectToAction("AllEmpLeavesList");
            }
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
            ViewBag.ReportingManagerID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ReportingManagerID);
            ViewBag.EmployeeID = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.EmployeeID);
            ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            return View(appliedLeaveDetail);
        }


        // GET: ManagerLeave/Edit/5
        public ActionResult ManagerApproveLeaveDetails(int? LeaveID)
        {
            EmployeeDetail empdetails = new EmployeeDetail();
            empdetails.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            if (LeaveID == null)
            {
                // return RedirectToAction("Contact", "Home");
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(LeaveID);
            if (appliedLeaveDetail == null)
            {
                // return RedirectToAction("Contact", "Home");  
                return HttpNotFound();
            }
            //
            ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode");
            
            ViewBag.EmployeeID = empdetails.EmployeeID;
            ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
            appliedLeaveDetail.EmployeeName = appliedLeaveDetail.EmployeeName;
            //
            ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
            ViewBag.ReportingManagerID = appliedLeaveDetail.ReportingManagerID;
            Session["RMID"] = appliedLeaveDetail.ReportingManagerID;
            Session["RMName"] = appliedLeaveDetail.ReportingManager;
            /********** on 22/06/2020 Leave status as 'Admin Approval' should not be bind for roles Employee, Manager *************/
            int RoleID = Convert.ToInt32(Session["RoleID"].ToString());
            if (RoleID != 1)
            {
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID).Where(a=>a.Value!="4");                 
            }  
            else
            ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
            ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
            Session["ErrorMessage"] = "0";
            return View(appliedLeaveDetail);
        }

        // POST: ManagerLeave/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public  ActionResult ManagerApproveLeaveDetails([Bind(Include = "LeaveID,EmployeeID,LeaveTypeID,StartDate,EndDate,NoofLeaveTaken,ReportingManagerID,ReportingManagerMailID,ModuleLeadMailID,ReasonforLeave,LeaveStatusID,EmergencyContact,InsertedDate,InsertedBy,ModifiedDate,ModifiedBy,ApprovedStartDate,ApprovedEndDate,ApprovedNoofDays,ApprovedBy,ApprovedReason,ApprovedDate,EmployeeName,ReportingManager")] AppliedLeaveDetail appliedLeaveDetail)
        {
            //appliedLeaveDetail.LeaveID = LeaveID;
            EmployeeDetail employeeDetail = new EmployeeDetail();
            employeeDetail.EmployeeID = appliedLeaveDetail.EmployeeID; // added on 22 - apr
            ////////////employeeDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString()); //commented on 22-apr
            ////////employeeDetail = db.EmployeeDetails.Find(employeeDetail.EmployeeID);
            ////////Session["RMID"] = employeeDetail.ReportingManagerID;
            ////////Session["RMName"] = employeeDetail.ReportingManager;
            if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                appliedLeaveDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
            if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                appliedLeaveDetail.ReportingManager = Session["RMName"].ToString();
            ////appliedLeaveDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            ////appliedLeaveDetail.EmployeeName = appliedLeaveDetail.EmployeeName;
            //appliedLeaveDetail.LeaveStatusID = 3;
            AppliedLeaveDetail appliedLeaveDetails = db.AppliedLeaveDetails.Find(appliedLeaveDetail.LeaveID);
            appliedLeaveDetail.EmployeeID = appliedLeaveDetails.EmployeeID; //Convert.ToInt32(Session["EmployeeID"].ToString());
            appliedLeaveDetail.EmployeeName = appliedLeaveDetails.EmployeeName;
            try
            {
                if (string.IsNullOrEmpty(appliedLeaveDetail.ApprovedReason) && appliedLeaveDetail.LeaveStatusID ==2)
                    {
                    Session["ErrorMessage"] = "1";
                    ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                    //ViewBag.ReportingManagerID =  appliedLeaveDetail.ReportingManagerID;
                    ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
                    ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
                    ViewBag.EmployeeID = appliedLeaveDetail.EmployeeID;
                    ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
                    ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
                    return View(appliedLeaveDetail);
                }
                if (ModelState.IsValid)
                {
                    string result = UnicalLMS.Gateway.DALEmployeeGateway.UpdateLeaveInfo(ref appliedLeaveDetail);
                    //db.Entry(appliedLeaveDetail).State = EntityState.Modified;
                    //db.AppliedLeaveDetails.Attach(appliedLeaveDetail);
                    //appliedLeaveDetail.ApprovedReason = "John"; // State = Modified, and only the FirstName property is dirty.                    
                    //db.SaveChanges();
                    return RedirectToAction("ManagerLeaveDetailsList");
                }
                ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                //ViewBag.ReportingManagerID =  appliedLeaveDetail.ReportingManagerID;
                ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
                ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
                ViewBag.EmployeeID =  appliedLeaveDetail.EmployeeID;
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
                ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
                Session["ErrorMessage"] = "0";
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(appliedLeaveDetail);

        }
        // POST: ManagerLeave/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ManagerApproveLeaveDetails1([Bind(Include = "LeaveID,EmployeeID,LeaveTypeID,StartDate,EndDate,NoofLeaveTaken,ReportingManagerID,ReportingManagerMailID,ModuleLeadMailID,ReasonforLeave,LeaveStatusID,EmergencyContact,InsertedDate,InsertedBy,ModifiedDate,ModifiedBy,ApprovedStartDate,ApprovedEndDate,ApprovedNoofDays,ApprovedBy,ApprovedReason,ApprovedDate,EmployeeName,ReportingManager")] AppliedLeaveDetail appliedLeaveDetail)
        {
            //appliedLeaveDetail.LeaveID = LeaveID;
            EmployeeDetail employeeDetail = new EmployeeDetail();
            employeeDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            ////////employeeDetail = db.EmployeeDetails.Find(employeeDetail.EmployeeID);
            ////////Session["RMID"] = employeeDetail.ReportingManagerID;
            ////////Session["RMName"] = employeeDetail.ReportingManager;
            if (!string.IsNullOrEmpty(Session["RMID"].ToString()))
                appliedLeaveDetail.ReportingManagerID = Convert.ToInt32(Session["RMID"].ToString());
            if (!string.IsNullOrEmpty(Session["RMName"].ToString()))
                appliedLeaveDetail.ReportingManager = Session["RMName"].ToString();
            ////appliedLeaveDetail.EmployeeID = Convert.ToInt32(Session["EmployeeID"].ToString());
            ////appliedLeaveDetail.EmployeeName = appliedLeaveDetail.EmployeeName;
            //appliedLeaveDetail.LeaveStatusID = 3;
            AppliedLeaveDetail appliedLeaveDetails = db.AppliedLeaveDetails.Find(appliedLeaveDetail.LeaveID);
            appliedLeaveDetail.EmployeeID = appliedLeaveDetails.EmployeeID; //Convert.ToInt32(Session["EmployeeID"].ToString());
            appliedLeaveDetail.EmployeeName = appliedLeaveDetails.EmployeeName;
            try
            {
                if (string.IsNullOrEmpty(appliedLeaveDetail.ApprovedReason) && appliedLeaveDetail.LeaveStatusID == 2)
                {
                    Session["ErrorMessage"] = "1";
                    ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                    //ViewBag.ReportingManagerID =  appliedLeaveDetail.ReportingManagerID;
                    ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
                    ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
                    ViewBag.EmployeeID = appliedLeaveDetail.EmployeeID;
                    ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
                    ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
                    return View(appliedLeaveDetail);
                }
                if (ModelState.IsValid)
                {
                    //db.Entry(appliedLeaveDetail).State = EntityState.Modified;
                    db.AppliedLeaveDetails.Attach(appliedLeaveDetail);
                    db.SaveChanges();
                    return RedirectToAction("ManagerLeaveDetailsList");
                }
                ViewBag.ApprovedBy = new SelectList(db.EmployeeDetails, "EmployeeID", "EmployeeCode", appliedLeaveDetail.ApprovedBy);
                //ViewBag.ReportingManagerID =  appliedLeaveDetail.ReportingManagerID;
                ViewBag.RMList = eManager.MangersList(appliedLeaveDetail.EmployeeID);
                ViewBag.RMList = new SelectList(ViewBag.RMList, "ReportingManagerID", "ReportingManager", appliedLeaveDetail.ReportingManagerID);
                ViewBag.EmployeeID = appliedLeaveDetail.EmployeeID;
                ViewBag.LeaveStatusID = new SelectList(db.LeaveStatus_Lkp, "LeaveStatusID", "LeaveStatus", appliedLeaveDetail.LeaveStatusID);
                ViewBag.LeaveTypeID = new SelectList(db.LeaveType_Lkp, "LeaveTypeID", "LeaveType", appliedLeaveDetail.LeaveTypeID);
                Session["ErrorMessage"] = "0";
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var errors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        // get the error message 
                        string errorMessage = validationError.ErrorMessage;
                    }
                }
            }
            return View(appliedLeaveDetail);

        }

        // GET: ManagerLeave/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                //return RedirectToAction("Contact", "Home"); 
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(id);
            if (appliedLeaveDetail == null)
            {
                // return RedirectToAction("Contact", "Home"); //
                return HttpNotFound();
            }
            return View(appliedLeaveDetail);
        }

        // POST: ManagerLeave/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            AppliedLeaveDetail appliedLeaveDetail = db.AppliedLeaveDetails.Find(id);
            db.AppliedLeaveDetails.Remove(appliedLeaveDetail);
            db.SaveChanges();
            return RedirectToAction("ManagerLeaveDetailsList");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
