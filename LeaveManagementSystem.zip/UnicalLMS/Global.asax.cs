﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace UnicalLMS
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        /////////////////////////////////////////////////////////////
        //// The below code for restricted after sucessfully logout  to
        //// enter in application through click on back browser back button.(Added by Aparna)
        /////////////////////////////////////////////////////////
        protected void Application_BeginRequest()
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
        }
        ///////////////////////////////////////////////////////////
        // before deployment, Make these below lines to uncommented
        ///////////////////////////////////////////////////////

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            if (!Response.IsRequestBeingRedirected)
            {
                Response.Clear();
                Server.ClearError();
                Response.Redirect("Error.cshtm");
                // Response.Redirect("~/Home/Error");
            }
        }
    }
}
