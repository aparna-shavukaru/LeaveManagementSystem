﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UnicalLMS.Gateway;
using UnicalLMS.Models;

namespace UnicalLMS.BusinessLayer
{
    public class BLEmployee
    {
        private DALEmployeeGateway eGateway = new DALEmployeeGateway();

        public List<Models.AppliedLeaveDetail> RMList(int EmployeeID)
        {
            return eGateway.RMList(EmployeeID);
        }
        public List<Models.EmployeeDetail> MangersList(int EmployeeID)
        {
            return eGateway.MangersList(EmployeeID);
        }

        public List<EmployeeDetail> AllEmployeeEmailList(string employeeName)
        {
            return eGateway.AllEmployeeEmailList(employeeName);
        }

        public List<EmployeeDetail> EmployeeList(int employeeId)
        {
            return eGateway.EmployeeList(employeeId);
        }

        public bool IsEmailExists(string email)
        {
            return eGateway.IsEmailExist(email); 
        }

        public bool IsEmpIDExists(string empID)
        {
            return eGateway.IsEmpIDExists(empID);
        }

        //public static int UpdateEmployeeDetails(ref EmployeeDetail employeeDetail)
        //{
        //    return eGateway.UpdateEmployeeDetails1(ref employeeDetail);
        //}
    }
}